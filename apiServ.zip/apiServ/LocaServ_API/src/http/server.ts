import { PrismaClient } from "@prisma/client/extension";
import { fastify } from "fastify";
import { z } from "zod";
import { prisma } from "../lib/prisma";
import { criarJogador } from "./routes/criar-jogador";
import { criarPartida } from "./routes/criar-partida";

const app = fastify()

app.register(criarJogador)
app.register(criarPartida)

app.listen({port: 5432}).then( () => {
    console.log('SERVIDOR RODANDO')
})  