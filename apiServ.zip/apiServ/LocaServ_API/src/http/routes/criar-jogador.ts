import { FastifyInstance, FastifyRequest, FastifyReply } from "fastify";
import z from "zod";
import { PrismaClient } from "@prisma/client/extension";
import { prisma } from "../../lib/prisma";

export async function criarJogador(app: FastifyInstance){
    app.post('/criarJogador', async (request: FastifyRequest, reply: FastifyReply) => {
       
            const requestBody = z.object({
                NAME_JOGADOR: z.string(),
                EMAIL_JOGADOR: z.string(),
                SENHA_JOGADOR: z.string()

            });
    
            const { NAME_JOGADOR, EMAIL_JOGADOR, SENHA_JOGADOR } = requestBody.parse(request.body);
        
            const jogadorCriado = await prisma.jogador.create({
                data: {
                
                    NAME_JOGADOR,
                    EMAIL_JOGADOR,
                    SENHA_JOGADOR
                }
            });
    
            return reply.status(201).send(jogadorCriado);
        
    });


}