import fastify from 'fastify';
import { PrismaClient } from "@prisma/client/extension";
import { z } from 'zod';

const app = fastify();
const prisma = new PrismaClient();

const CreatePartidaSchema = z.object({
  local: z.string(),
  hora: z.string(),
  jogadores: z.array(z.object({
    name: z.string(),
    email: z.string(),
    password: z.string(),
    phone: z.string()
  }))
});

// Rota para criar uma partida com jogadores
app.post('/partida', async (request, reply) => {
  try {
    const { local, hora, jogadores } = CreatePartidaSchema.parse(request.body);

    // Cria a partida no banco de dados
    const partida = await prisma.partida.create({
      data: {
        local,
        hora,
        Jogador: {
          createMany: {
            data: jogadores.map(jogador => ({
              name: jogador.name,
              email: jogador.email,
              password: jogador.password,
              phone: jogador.phone
            }))
          }
        }
      },
      include: {
        Jogador: true
      }
    });

    reply.code(201).send(partida);
  } catch (error) {
    reply.code(500).send({ error: 'Erro ao criar a partida' });
  }
});

// Inicia o servidor
const start = async () => {
  try {
    await app.listen(3000);
    console.log('Servidor rodando em http://localhost:5432');
  } catch (err) {
    console.error(err);
    process.exit(1);
  }
};

start();