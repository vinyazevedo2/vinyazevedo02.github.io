import { FastifyInstance, FastifyRequest, FastifyReply } from "fastify";
import z from "zod";
import { PrismaClient } from "@prisma/client/extension";
import { prisma } from "../../lib/prisma";

export async function criarPartida(app: FastifyInstance){
    app.post('/criarPartida', async (request: FastifyRequest, reply: FastifyReply) => {
       
            const requestBody = z.object({
                LOCAL_PARTIDA: z.string(),
                HORA_PARTIDA: z.string(),

            });
    
            const { LOCAL_PARTIDA, HORA_PARTIDA } = requestBody.parse(request.body);
        
            const partidaCriado = await prisma.partida.create({
                data: {
                
                    LOCAL_PARTIDA,
                    HORA_PARTIDA,
        
                }
            });
    
            return reply.status(201).send(partidaCriado);
        
    });


}