import { PrismaClient } from "@prisma/client/extension"

export const prisma = new PrismaClient({
    log: ['query']
    
})

